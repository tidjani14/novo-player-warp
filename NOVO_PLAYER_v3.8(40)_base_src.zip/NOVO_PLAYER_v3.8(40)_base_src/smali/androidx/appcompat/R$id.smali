.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_bar:I = 0x7f0b003a

.field public static final action_bar_activity_content:I = 0x7f0b003b

.field public static final action_bar_container:I = 0x7f0b003c

.field public static final action_bar_root:I = 0x7f0b003d

.field public static final action_bar_spinner:I = 0x7f0b003e

.field public static final action_bar_subtitle:I = 0x7f0b003f

.field public static final action_bar_title:I = 0x7f0b0040

.field public static final action_context_bar:I = 0x7f0b0042

.field public static final action_menu_divider:I = 0x7f0b0048

.field public static final action_menu_presenter:I = 0x7f0b0049

.field public static final action_mode_bar:I = 0x7f0b004a

.field public static final action_mode_bar_stub:I = 0x7f0b004b

.field public static final action_mode_close_button:I = 0x7f0b004c

.field public static final activity_chooser_view_content:I = 0x7f0b0050

.field public static final add:I = 0x7f0b0051

.field public static final alertTitle:I = 0x7f0b0054

.field public static final buttonPanel:I = 0x7f0b00a8

.field public static final checkbox:I = 0x7f0b00bd

.field public static final checked:I = 0x7f0b00be

.field public static final content:I = 0x7f0b00ce

.field public static final contentPanel:I = 0x7f0b00cf

.field public static final custom:I = 0x7f0b00e1

.field public static final customPanel:I = 0x7f0b00e2

.field public static final decor_content_parent:I = 0x7f0b00e9

.field public static final default_activity_button:I = 0x7f0b00ea

.field public static final edit_query:I = 0x7f0b011c

.field public static final expand_activities_button:I = 0x7f0b0162

.field public static final expanded_menu:I = 0x7f0b0163

.field public static final group_divider:I = 0x7f0b0188

.field public static final home:I = 0x7f0b01b0

.field public static final icon:I = 0x7f0b01ba

.field public static final image:I = 0x7f0b01c0

.field public static final listMode:I = 0x7f0b022b

.field public static final list_item:I = 0x7f0b022c

.field public static final message:I = 0x7f0b0285

.field public static final multiply:I = 0x7f0b02aa

.field public static final none:I = 0x7f0b02b9

.field public static final normal:I = 0x7f0b02ba

.field public static final off:I = 0x7f0b02c1

.field public static final on:I = 0x7f0b02c2

.field public static final parentPanel:I = 0x7f0b02ce

.field public static final progress_circular:I = 0x7f0b02e3

.field public static final progress_horizontal:I = 0x7f0b02e4

.field public static final radio:I = 0x7f0b02e5

.field public static final screen:I = 0x7f0b0306

.field public static final scrollIndicatorDown:I = 0x7f0b0308

.field public static final scrollIndicatorUp:I = 0x7f0b0309

.field public static final scrollView:I = 0x7f0b030a

.field public static final search_badge:I = 0x7f0b030c

.field public static final search_bar:I = 0x7f0b030d

.field public static final search_button:I = 0x7f0b030f

.field public static final search_close_btn:I = 0x7f0b0310

.field public static final search_edit_frame:I = 0x7f0b0311

.field public static final search_go_btn:I = 0x7f0b0312

.field public static final search_mag_icon:I = 0x7f0b0313

.field public static final search_plate:I = 0x7f0b0315

.field public static final search_src_text:I = 0x7f0b0316

.field public static final search_voice_btn:I = 0x7f0b0324

.field public static final select_dialog_listview:I = 0x7f0b0329

.field public static final shortcut:I = 0x7f0b0331

.field public static final spacer:I = 0x7f0b033f

.field public static final split_action_bar:I = 0x7f0b0343

.field public static final src_atop:I = 0x7f0b0348

.field public static final src_in:I = 0x7f0b0349

.field public static final src_over:I = 0x7f0b034a

.field public static final submenuarrow:I = 0x7f0b037a

.field public static final submit_area:I = 0x7f0b037b

.field public static final tabMode:I = 0x7f0b0380

.field public static final textSpacerNoButtons:I = 0x7f0b0391

.field public static final textSpacerNoTitle:I = 0x7f0b0392

.field public static final title:I = 0x7f0b03a1

.field public static final titleDividerNoCustom:I = 0x7f0b03a2

.field public static final title_template:I = 0x7f0b03a5

.field public static final topPanel:I = 0x7f0b03a9

.field public static final unchecked:I = 0x7f0b0406

.field public static final uniform:I = 0x7f0b0407

.field public static final up:I = 0x7f0b0409

.field public static final wrap_content:I = 0x7f0b042b


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
